import sys
import threading

from functions_PID import (
    DataLogger,
    init_hardware,
    shut_down_hardware,
    pid_loop
)

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QPushButton, QVBoxLayout, QHBoxLayout,
    QTextEdit, QFileDialog, QDoubleSpinBox, QLabel
)
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QTextCursor

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


# ------------------------------------------------------------
# Przechwytywanie print() do okna logów
# ------------------------------------------------------------
class EmittingStream:
    def __init__(self, text_edit):
        self.text_edit = text_edit

    def write(self, text):
        self.text_edit.moveCursor(QTextCursor.MoveOperation.End)
        self.text_edit.insertPlainText(text)

    def flush(self):
        pass


# ------------------------------------------------------------
# Widget z wykresem matplotlib
# ------------------------------------------------------------
class PlotWidget(QWidget):
    def __init__(self, logger):
        super().__init__()

        self.logger = logger
        self.t_set = None

        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        self.ax = self.figure.add_subplot(111)

        layout = QVBoxLayout()
        layout.addWidget(self.canvas)
        self.setLayout(layout)

        self.line_temp, = self.ax.plot([], [], label="Temperature [°C]")
        self.line_tset, = self.ax.plot([], [], "--", label="T_set")

        self.ax.set_title("Live plot")
        self.ax.set_xlabel("Time [s]")
        self.ax.set_ylabel("Temperature [°C]")
        self.ax.legend()
        self.ax.grid()

    def set_t_set(self, t_set: float):
        self.t_set = t_set

    def update_plot(self):
        if not self.logger or not self.logger.time_log:
            return

        t = self.logger.time_log
        temp = self.logger.temp_log

        self.line_temp.set_data(t, temp)

        if self.t_set is not None:
            self.line_tset.set_data(t, [self.t_set] * len(t))

        self.ax.relim()
        self.ax.autoscale_view()
        self.canvas.draw_idle()


# ------------------------------------------------------------
# Główne okno
# ------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("PyQt6 GUI – PID temperature control")

        self.logger = DataLogger()
        self.t_set = None

        central = QWidget()
        self.setCentralWidget(central)

        # --- Wykres
        self.plot_widget = PlotWidget(self.logger)

        # --- Logi
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(150)
        sys.stdout = EmittingStream(self.log_box)

        # --- Set temperature
        self.temp_label = QLabel("Set temperature [°C]")
        self.temp_input = QDoubleSpinBox()
        self.temp_input.setRange(18.0, 28.0)
        self.temp_input.setDecimals(2)
        self.temp_input.setSingleStep(0.5)
        self.temp_input.setValue(25.0)

        # --- Przyciski
        self.start_btn = QPushButton("Start")
        self.stop_btn = QPushButton("Stop")
        self.fan_btn = QPushButton("Fan OFF")
        self.save_btn = QPushButton("Save to file")

        self.start_btn.clicked.connect(self.start)
        self.stop_btn.clicked.connect(self.stop)
        self.fan_btn.clicked.connect(self.toggle_fan)
        self.save_btn.clicked.connect(self.save_to_file)

        temp_layout = QHBoxLayout()
        temp_layout.addWidget(self.temp_label)
        temp_layout.addWidget(self.temp_input)

        btn_layout = QHBoxLayout()
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addWidget(self.fan_btn)
        btn_layout.addWidget(self.save_btn)

        main_layout = QVBoxLayout()
        main_layout.addLayout(temp_layout)
        main_layout.addWidget(self.plot_widget)
        main_layout.addLayout(btn_layout)
        main_layout.addWidget(self.log_box)

        central.setLayout(main_layout)

        # --- Timer wykresu
        self.timer = QTimer()
        self.timer.timeout.connect(self.plot_widget.update_plot)

        self.running = threading.Event()
        self.thread = None

        self.fan_on = False

        # PID parameters
        self.Kp = 1
        self.Ki = 0.03
        self.Kd = 0.1

        self.ser_arduino = None
        self.ser_psu = None

    # --------------------------------------------------------

    def start(self):
        if self.thread and self.thread.is_alive():
            return

        self.t_set = float(self.temp_input.value())
        print(f"[INFO] Start PID, T_set = {self.t_set:.2f}")

        self.temp_input.setEnabled(False)

        self.ser_arduino, self.ser_psu = init_hardware()

        self.logger = DataLogger()
        self.plot_widget.logger = self.logger
        self.plot_widget.set_t_set(self.t_set)

        self.running.set()

        self.thread = threading.Thread(
            target=pid_loop,
            args=(
                self.ser_arduino,
                self.ser_psu,
                self.Kp,
                self.Ki,
                self.Kd,
                self.t_set,
                self.logger,
                self.running
            ),
            daemon=True
        )
        self.thread.start()

        self.timer.start(100)

    # --------------------------------------------------------

    def stop(self):
        print("[INFO] Stop PID")

        self.running.clear()

        if self.thread:
            self.thread.join(timeout=5)
            self.thread = None

        self.timer.stop()

        try:
            shut_down_hardware(self.ser_arduino, self.ser_psu)
        except Exception as e:
            print(f"[WARN] Hardware shutdown failed: {e}")

        self.temp_input.setEnabled(True)

    # --------------------------------------------------------

    def toggle_fan(self):
        self.fan_on = not self.fan_on
        state = "ON" if self.fan_on else "OFF"
        self.fan_btn.setText(f"Fan {state}")

        if self.ser_arduino:
            cmd = "F1" if self.fan_on else "F0"
            self.ser_arduino.write(cmd.encode())

        print(f"[INFO] Fan {state}")

    # --------------------------------------------------------

    def save_to_file(self):
        if not self.logger.time_log:
            print("[WARN] Logger is empty")
            return

        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Save data to CSV",
            "",
            "CSV files (*.csv)"
        )
        if not filename:
            return

        self.logger.save_csv(filename)
        print(f"[INFO] Data saved to {filename}")

    # --------------------------------------------------------

    def closeEvent(self, event):
        self.stop()
        event.accept()


# ------------------------------------------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.resize(900, 600)
    window.show()
    sys.exit(app.exec())
